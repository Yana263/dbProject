﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbProject
{
    class Users
    {
        public int idUser { get; set; }
        public string login { get; set; }
        public string password { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }


    }
}
